#!/usr/bin/env python
#encoding: utf-8


from redis import *

class Cache(Redis):
    '''
    报警的时候。会在短时间内发送X数据。该缓存会对数据进行一个整理.
    简单实现。 key => [time, bounds].  bounds
    '''
    def __init__(self, host, port):

        Redis.__init__(self,host=host,port=port)




